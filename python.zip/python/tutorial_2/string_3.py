"""
email
    ramesh@gmail.com
    rajesh@gmail
    @ram@gmail.com
    nit...esh@gmail.com
    nitesh@gmail@com
    java.arun@kumar_gmail.com
    
    
    find if given email id is valid or not
    
    count, index, 
"""

"""
first.last@gmail.com
first_last@gmail.com

"""