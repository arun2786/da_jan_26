# Ticket Info

passenger = "Ramesh"
from_place = "Kanpur"
to_place = "Jaipur"
date = "15Feb2026"
amount = 142.60
is_confirmed = True 
age = 32

print("Passenger name: ",passenger)
print("Passenger age: ",age)
print("Journey: ",from_place," to ", to_place)
print("Journey date: ", date)
print("Bill amount: ", amount)
print("Ticket Status (Confirmed): ",is_confirmed)

print(f"Passenger name: {passenger}")
print(f"Passenger age: {age}")
print(f"Journey: {from_place} to {to_place}")
print(f"Journey date: {date}")
print(f"Bill amount: {amount}")
print(f"Ticket Status (Confirmed): {is_confirmed}")


# print("Passenger name: ",passenger,", Passenger age: ",age,", Journey: ",from_place," to ", to_place,", Journey date: ", date,"Bill amount: ", amount,"Ticket Status (Confirmed): ",is_confirmed, sep="")
# print("=========")
# print(f"Passenger name: {passenger}, Passenger age: {age}, Journey: {from_place} to {to_place}, Journey date: {date}, Bill amount: {amount}, Ticket Status (Confirmed): {is_confirmed}")
