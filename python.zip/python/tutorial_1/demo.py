print("Basic Calc")

a = 15
b = 6

print(a+b)