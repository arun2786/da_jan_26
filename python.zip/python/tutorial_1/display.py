name = "Ramesh"
age = 32

print("Student's Details")
print("Name:",name)
print("Age:",age)