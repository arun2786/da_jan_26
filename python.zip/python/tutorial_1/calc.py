a = float(input("Enter first number: ")) # 5
b = float(input("Enter second number: ")) # 2

print("Sum",a+b)
print("Sub",a-b)
print("Mul",a*b)


# / -> divides to decimal points
print("Div (/)",a/b) # 2.5

# // -> divides to whole number -> quotient
print("Div (//)",a//b) # 2

# % -> divides and finds remainder 
print("Div (%)",a%b) # 1






